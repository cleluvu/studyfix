# Tìm số lớn nhất trong ba số

**Mã bài:** JAVA010  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc ba số nguyên; in giá trị lớn nhất.

## Ràng buộc và trường hợp biên

Các số có thể bằng nhau.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
