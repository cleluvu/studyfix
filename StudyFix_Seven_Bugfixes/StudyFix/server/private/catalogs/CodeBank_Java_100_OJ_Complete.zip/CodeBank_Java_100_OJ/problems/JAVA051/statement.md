# Thống kê tần suất ký tự

**Mã bài:** JAVA051  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc một dòng chỉ chứa chữ cái ASCII thường a-z; in 26 tần suất theo thứ tự a-z trên một dòng.

## Ràng buộc và trường hợp biên

Ký tự không xuất hiện có tần suất 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
