# Lớp Rectangle

**Mã bài:** JAVA065  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo public class Rectangle có private double width,height; constructor, getter, public double area() và perimeter().

## Ràng buộc và trường hợp biên

Kích thước đầu vào dương.

## Quy ước kiểm thử bổ sung

Các getter bắt buộc: getWidth(), getHeight().

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
