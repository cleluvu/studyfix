public class Solution {
    public static java.util.Set<Integer> intersection(java.util.Set<Integer> a,java.util.Set<Integer> b) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
