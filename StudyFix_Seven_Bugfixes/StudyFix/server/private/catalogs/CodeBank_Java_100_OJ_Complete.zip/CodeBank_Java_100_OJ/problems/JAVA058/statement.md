# Method tìm UCLN

**Mã bài:** JAVA058  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static long gcd(long a,long b) theo thuật toán Euclid.

## Ràng buộc và trường hợp biên

a,b không âm, không đồng thời bằng 0.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static long gcd(long a,long b)
```
