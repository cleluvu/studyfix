import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();java.util.TreeMap<String,Integer> a=new java.util.TreeMap<>();for(int i=0;i<n;i++)a.merge(sc.next(),1,Integer::sum);String best="NONE";int k=-1;for(var e:a.entrySet())if(e.getValue()>k){k=e.getValue();best=e.getKey();}System.out.println(best);}
}
