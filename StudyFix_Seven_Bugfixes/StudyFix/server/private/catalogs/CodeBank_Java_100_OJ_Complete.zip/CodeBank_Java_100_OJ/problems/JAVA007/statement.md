# Tính tiền điện đơn giá cố định

**Mã bài:** JAVA007  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc số kWh không âm và đơn giá mỗi kWh là số thực không âm; xuất tổng tiền với 2 chữ số thập phân.

## Ràng buộc và trường hợp biên

Không áp dụng biểu giá bậc thang.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
