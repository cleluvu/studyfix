import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static java.util.Set<Integer> intersection(java.util.Set<Integer> a,java.util.Set<Integer> b) {java.util.Set<Integer> s=new java.util.HashSet<>(a);s.retainAll(b);return s;}}
