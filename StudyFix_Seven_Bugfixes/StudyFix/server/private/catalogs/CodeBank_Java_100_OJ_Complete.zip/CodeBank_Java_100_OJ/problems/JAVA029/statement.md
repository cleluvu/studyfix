# Đếm số chẵn trong mảng

**Mã bài:** JAVA029  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int countEven(int[] a) trả số phần tử chẵn.

## Ràng buộc và trường hợp biên

Mảng có thể rỗng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int countEven(int[] a)
```
