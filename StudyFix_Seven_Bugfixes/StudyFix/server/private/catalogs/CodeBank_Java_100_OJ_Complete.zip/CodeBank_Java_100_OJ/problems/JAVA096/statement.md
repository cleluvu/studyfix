# Tìm kiếm nhị phân

**Mã bài:** JAVA096  
**Week:** 12 – Thuật toán và bài tổng hợp  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int binarySearchFirst(int[] a,int x) trả vị trí đầu tiên của x trên mảng đã tăng dần hoặc -1.

## Ràng buộc và trường hợp biên

Yêu cầu O(log n).

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int binarySearchFirst(int[] a,int x)
```
