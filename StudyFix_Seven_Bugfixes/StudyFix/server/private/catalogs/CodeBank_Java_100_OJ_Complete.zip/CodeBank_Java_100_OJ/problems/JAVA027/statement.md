# Tổng các phần tử mảng

**Mã bài:** JAVA027  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n rồi n số nguyên; in tổng các phần tử bằng long.

## Ràng buộc và trường hợp biên

n có thể bằng 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
