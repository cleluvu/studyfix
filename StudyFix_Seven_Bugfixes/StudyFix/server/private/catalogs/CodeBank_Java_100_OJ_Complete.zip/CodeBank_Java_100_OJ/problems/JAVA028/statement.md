# Tìm phần tử lớn nhất

**Mã bài:** JAVA028  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int findMax(int[] a) trả phần tử lớn nhất của mảng.

## Ràng buộc và trường hợp biên

a khác null và có ít nhất một phần tử.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int findMax(int[] a)
```
