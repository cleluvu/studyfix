# Giải phương trình bậc nhất

**Mã bài:** JAVA013  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc a,b thực biểu diễn ax+b=0; in NO_SOLUTION, INFINITE hoặc nghiệm x với 4 chữ số thập phân.

## Ràng buộc và trường hợp biên

Quy ước so sánh a,b với 0 chính xác cho input nguyên dạng thập phân đơn giản.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
