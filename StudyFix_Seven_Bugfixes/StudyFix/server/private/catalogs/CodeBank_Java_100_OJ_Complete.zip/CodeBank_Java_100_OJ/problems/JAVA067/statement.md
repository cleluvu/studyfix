# Lớp BankAccount

**Mã bài:** JAVA067  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class BankAccount có id, balance private; constructor nhận id và balance ban đầu; deposit(amount), withdraw(amount) trả boolean, getBalance().

## Ràng buộc và trường hợp biên

Không cho rút quá số dư; amount phải dương.

## Quy ước kiểm thử bổ sung

Signature: BankAccount(String id,double balance), String getId(), double getBalance(), void deposit(double amount), boolean withdraw(double amount). amount không dương ném IllegalArgumentException.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
