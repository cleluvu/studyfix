# Từ xuất hiện nhiều nhất bằng Map

**Mã bài:** JAVA085  
**Week:** 10 – Collections và Generics  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n rồi n từ ASCII thường; in từ xuất hiện nhiều nhất, nếu hòa chọn từ nhỏ nhất theo từ điển.

## Ràng buộc và trường hợp biên

n>=1.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
