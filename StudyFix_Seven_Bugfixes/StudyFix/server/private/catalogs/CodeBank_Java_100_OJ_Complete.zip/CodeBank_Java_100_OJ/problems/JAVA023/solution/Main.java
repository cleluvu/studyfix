import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);long n=sc.nextLong();java.util.List<Long> a=new java.util.ArrayList<>(),b=new java.util.ArrayList<>();for(long i=1;i<=n/i;i++)if(n%i==0){a.add(i);if(i!=n/i)b.add(n/i);}java.util.Collections.reverse(b);a.addAll(b);System.out.println(a.toString().replace("[","").replace("]","").replace(", "," "));}
}
