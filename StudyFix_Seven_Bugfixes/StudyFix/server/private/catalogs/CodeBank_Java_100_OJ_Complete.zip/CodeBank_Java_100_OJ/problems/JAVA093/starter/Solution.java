public class Solution {
    public static void saveNames(java.nio.file.Path path,java.util.List<String> names) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
