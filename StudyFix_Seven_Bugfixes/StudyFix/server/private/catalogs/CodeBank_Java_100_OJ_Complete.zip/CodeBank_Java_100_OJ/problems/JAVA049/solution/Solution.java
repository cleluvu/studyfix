import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static String normalizeSpaces(String s) {return s.trim().replaceAll("\\s+"," ");}}
