# Quản lý thư viện bằng OOP

**Mã bài:** JAVA099  
**Week:** 12 – Thuật toán và bài tổng hợp  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class Library quản lý Book(id,title) duy nhất theo id; addBook(Book), removeBook(String), findBook(String), size(), listBooks() theo id tăng.

## Ràng buộc và trường hợp biên

Không thêm id trùng; list trả bản sao bảo vệ dữ liệu.

## Quy ước kiểm thử bổ sung

Book(String id,String title), getter getId/getTitle; Library.addBook(Book) trả boolean (false nếu id đã tồn tại); removeBook(String) trả boolean; findBook(String) trả Book hoặc null; size() trả int.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
