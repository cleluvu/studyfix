# Tính giá trị biểu thức

**Mã bài:** JAVA005  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc ba số thực a,b,c; tính (a+b)*c - a*b và in kết quả với 2 chữ số thập phân.

## Ràng buộc và trường hợp biên

Sử dụng Locale.ROOT khi định dạng số.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
