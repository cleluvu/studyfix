# Lớp Book và quản lý mã ISBN

**Mã bài:** JAVA070  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class Book với isbn, title, price private; constructor, getter, setter giá kiểm tra không âm, toString() định dạng isbn / title / price.

## Ràng buộc và trường hợp biên

Không yêu cầu kiểm tra checksum ISBN.

## Quy ước kiểm thử bổ sung

Constructor Book(String isbn,String title,double price); getter getIsbn/getTitle/getPrice; setter setPrice(double), giá âm ném IllegalArgumentException.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
