# Tìm vị trí đầu tiên của x

**Mã bài:** JAVA030  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int firstIndex(int[] a, int x) trả chỉ số 0-based đầu tiên của x hoặc -1 nếu không có.

## Ràng buộc và trường hợp biên

Mảng có thể rỗng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int firstIndex(int[] a,int x)
```
