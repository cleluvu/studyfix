# Đa hình tính tổng diện tích

**Mã bài:** JAVA077  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static double totalArea(Shape[] shapes) cộng area() của từng phần tử Shape từ hệ thống cung cấp.

## Ràng buộc và trường hợp biên

Mảng có thể rỗng, phần tử không null.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static double totalArea(Shape[] shapes)
```
