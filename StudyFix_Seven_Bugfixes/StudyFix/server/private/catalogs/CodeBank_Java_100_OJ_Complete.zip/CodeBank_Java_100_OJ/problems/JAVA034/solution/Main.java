import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();int[]a=new int[n];for(int i=0;i<n;i++)a[i]=sc.nextInt();int x=sc.nextInt();java.util.List<Integer> b=new java.util.ArrayList<>();for(int z:a)if(z!=x)b.add(z);System.out.println(b.size());System.out.println(b.toString().replace("[","").replace("]","").replace(", "," "));}
}
