public class Solution {
    public static java.util.Map<String,Integer> frequency(java.util.List<String> words) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
