// TODO: Implement all fields, constructors and methods from the specification.
// You can replace this starter file.
public class Student {
}
