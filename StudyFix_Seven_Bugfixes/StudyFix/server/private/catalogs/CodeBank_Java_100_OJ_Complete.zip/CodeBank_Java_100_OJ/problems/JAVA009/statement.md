# Kiểm tra chẵn lẻ

**Mã bài:** JAVA009  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc số nguyên n, in EVEN nếu chẵn hoặc ODD nếu lẻ.

## Ràng buộc và trường hợp biên

Hỗ trợ số âm và 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
