import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static java.util.List<Integer> unique(java.util.List<Integer> a) {return new java.util.ArrayList<>(new java.util.LinkedHashSet<>(a));}}
