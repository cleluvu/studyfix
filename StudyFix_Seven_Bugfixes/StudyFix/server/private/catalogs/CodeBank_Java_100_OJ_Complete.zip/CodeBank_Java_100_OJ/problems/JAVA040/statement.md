# Chuyển vị ma trận

**Mã bài:** JAVA040  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc r,c và ma trận; in ma trận chuyển vị kích thước c×r, mỗi hàng trên một dòng.

## Ràng buộc và trường hợp biên

Phân tách các số bằng một khoảng trắng.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
