import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();if(n==0){System.out.println();return;}for(int i=0;i<(1<<n);i++){String s=Integer.toBinaryString(i);System.out.println("0".repeat(Math.max(0,n-s.length()))+s);}}
}
