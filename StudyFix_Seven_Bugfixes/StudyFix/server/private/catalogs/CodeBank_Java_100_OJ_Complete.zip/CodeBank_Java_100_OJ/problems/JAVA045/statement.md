# Xoay ma trận vuông 90 độ

**Mã bài:** JAVA045  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int[][] rotateClockwise(int[][] a), trả ma trận vuông xoay 90 độ theo chiều kim đồng hồ.

## Ràng buộc và trường hợp biên

Không thay đổi ma trận đầu vào.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int[][] rotateClockwise(int[][] a)
```
