import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int[][] rotateClockwise(int[][] a) {int n=a.length;int[][]r=new int[n][n];for(int i=0;i<n;i++)for(int j=0;j<n;j++)r[j][n-1-i]=a[i][j];return r;}}
