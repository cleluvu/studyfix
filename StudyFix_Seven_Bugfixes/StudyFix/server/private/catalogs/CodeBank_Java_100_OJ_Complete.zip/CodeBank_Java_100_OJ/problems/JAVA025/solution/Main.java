import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();long a=0,b=1;for(int i=0;i<n;i++){long t=a+b;a=b;b=t;}System.out.println(a);}
}
