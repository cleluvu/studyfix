# Chữ số hàng trăm chục đơn vị

**Mã bài:** JAVA006  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc một số nguyên n từ 100 đến 999; xuất lần lượt chữ số hàng trăm, chục và đơn vị.

## Ràng buộc và trường hợp biên

Không dùng xử lý chuỗi.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
