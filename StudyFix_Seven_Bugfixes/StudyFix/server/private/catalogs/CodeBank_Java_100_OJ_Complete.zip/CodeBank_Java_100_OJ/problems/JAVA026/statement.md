# Số hoàn hảo

**Mã bài:** JAVA026  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n nguyên dương; in YES nếu tổng các ước dương thực sự bằng n, ngược lại NO.

## Ràng buộc và trường hợp biên

n=1 không phải số hoàn hảo.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
