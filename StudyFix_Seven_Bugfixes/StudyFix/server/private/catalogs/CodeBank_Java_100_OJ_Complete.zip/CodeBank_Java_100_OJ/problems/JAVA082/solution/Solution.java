import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static java.util.Map<String,Integer> frequency(java.util.List<String> words) {java.util.Map<String,Integer> m=new java.util.HashMap<>();for(String s:words)m.merge(s,1,Integer::sum);return m;}}
