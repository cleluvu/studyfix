# Chu vi và diện tích hình chữ nhật

**Mã bài:** JAVA002  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc chiều dài và chiều rộng là hai số thực dương; in chu vi và diện tích, mỗi giá trị làm tròn 2 chữ số sau dấu phẩy.

## Ràng buộc và trường hợp biên

Các kích thước phải lớn hơn 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
