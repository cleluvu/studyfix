public class Solution {
    public static int firstIndex(int[] a,int x) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
