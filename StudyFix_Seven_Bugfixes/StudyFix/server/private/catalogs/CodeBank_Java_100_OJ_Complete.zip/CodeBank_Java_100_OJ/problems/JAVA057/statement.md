# Nạp chồng phương thức tính diện tích

**Mã bài:** JAVA057  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class AreaCalculator với hai public static method: area(double radius) tính diện tích hình tròn và area(double width,double height) tính diện tích hình chữ nhật.

## Ràng buộc và trường hợp biên

Đầu vào không âm, dùng Math.PI.

## Quy ước kiểm thử bổ sung

Bán kính, chiều rộng và chiều cao không âm; đánh giá kết quả double với tolerance 1e-9.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
