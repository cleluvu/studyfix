# Tìm phần tử lớn nhất ma trận

**Mã bài:** JAVA039  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int maxMatrix(int[][] a) trả giá trị lớn nhất.

## Ràng buộc và trường hợp biên

Ma trận chữ nhật và có ít nhất một phần tử.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int maxMatrix(int[][] a)
```
