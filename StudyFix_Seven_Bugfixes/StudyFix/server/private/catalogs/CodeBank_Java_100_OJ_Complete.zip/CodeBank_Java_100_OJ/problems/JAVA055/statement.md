# Method tính tổng mảng

**Mã bài:** JAVA055  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static long sum(int[] a) trả tổng mảng bằng long.

## Ràng buộc và trường hợp biên

Mảng rỗng trả 0.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static long sum(int[] a)
```
