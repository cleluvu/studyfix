# Lớp TimeOfDay

**Mã bài:** JAVA069  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class TimeOfDay có hour,minute,second, constructor hợp lệ, tick() tăng 1 giây, toString() HH:mm:ss.

## Ràng buộc và trường hợp biên

Giờ 0-23, phút/giây 0-59.

## Quy ước kiểm thử bổ sung

Signature TimeOfDay(int hour,int minute,int second), void tick(), toString() dạng HH:mm:ss; giá trị ngoài phạm vi ném IllegalArgumentException.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
