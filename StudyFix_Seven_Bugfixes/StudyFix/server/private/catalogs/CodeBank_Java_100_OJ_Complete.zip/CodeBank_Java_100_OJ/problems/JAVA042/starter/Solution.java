public class Solution {
    public static boolean isSymmetric(int[][] a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
