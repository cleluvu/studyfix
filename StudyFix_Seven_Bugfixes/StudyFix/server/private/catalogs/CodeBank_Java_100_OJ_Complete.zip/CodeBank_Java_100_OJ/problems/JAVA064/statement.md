# Lớp Student cơ bản

**Mã bài:** JAVA064  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo public class Student với private String name, private double score; constructor Student(String,double), getter và public boolean isPassed() trả score>=5.

## Ràng buộc và trường hợp biên

Không yêu cầu main.

## Quy ước kiểm thử bổ sung

Các phương thức getter bắt buộc: getName(), getScore().

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
