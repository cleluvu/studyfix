# Phân loại tam giác

**Mã bài:** JAVA014  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc ba độ dài cạnh thực; nếu không tạo tam giác in INVALID; ngược lại in EQUILATERAL, ISOSCELES hoặc SCALENE.

## Ràng buộc và trường hợp biên

Các cạnh phải dương và thỏa bất đẳng thức tam giác.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
