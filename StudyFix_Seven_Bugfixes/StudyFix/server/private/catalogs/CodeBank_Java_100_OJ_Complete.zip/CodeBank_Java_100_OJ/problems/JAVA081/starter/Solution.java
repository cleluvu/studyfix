public class Solution {
    public static java.util.List<Integer> unique(java.util.List<Integer> a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
