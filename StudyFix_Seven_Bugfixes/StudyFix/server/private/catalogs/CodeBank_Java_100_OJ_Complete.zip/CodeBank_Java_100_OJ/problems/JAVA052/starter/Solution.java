public class Solution {
    public static boolean isAnagram(String a,String b) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
