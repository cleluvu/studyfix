public class Solution {
    public static int countPrimes(int[] a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
