import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();java.util.List<String[]>a=new java.util.ArrayList<>();for(int i=0;i<n;i++)a.add(new String[]{sc.next(),sc.next(),sc.next()});a.sort((x,y)->{int c=Long.compare(Long.parseLong(y[1]),Long.parseLong(x[1]));if(c!=0)return c;c=Long.compare(Long.parseLong(x[2]),Long.parseLong(y[2]));return c!=0?c:x[0].compareTo(y[0]);});for(String[]v:a)System.out.println(v[0]+" "+v[1]+" "+v[2]);}
}
