# Tổng các phần tử ma trận

**Mã bài:** JAVA037  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc r,c và ma trận r×c số nguyên; in tổng tất cả phần tử kiểu long.

## Ràng buộc và trường hợp biên

r,c dương.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
