public class Solution {
    public static int binarySearchFirst(int[] a,int x) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
