#!/usr/bin/env python3
"""Offline trusted-reference smoke verifier; NOT a sandbox for student submissions."""
import argparse, json, pathlib, subprocess, tempfile, sys, shutil
ROOT = pathlib.Path(__file__).resolve().parent
FORMATTING='''static String fmt(Object x){if(x==null)return "null";Class<?> c=x.getClass();if(c.isArray()){if(x instanceof int[])return java.util.Arrays.toString((int[])x);if(x instanceof long[])return java.util.Arrays.toString((long[])x);if(x instanceof Object[])return java.util.Arrays.deepToString((Object[])x);}if(x instanceof java.util.Map)return new java.util.TreeMap<>((java.util.Map)x).toString();if(x instanceof java.util.Set)return new java.util.TreeSet<>((java.util.Set)x).toString();return x.toString();}'''
def run(command, **kwargs):
    try: return subprocess.run(command, timeout=12, capture_output=True, text=True, **kwargs)
    except subprocess.TimeoutExpired: return None

def verify(pid, candidate=None):
    meta=json.loads((ROOT/'problems'/pid/'problem.json').read_text())
    problem_dir=ROOT/'problems'/pid
    source=problem_dir/meta['reference_solution'] if candidate is None else pathlib.Path(candidate)
    kind=meta['java_structure']; judged=[]
    with tempfile.TemporaryDirectory(prefix='codebank_trusted_reference_') as tmp:
        td=pathlib.Path(tmp); copied=td/source.name; shutil.copy2(source,copied)
        for t in meta['test_cases']:
            if kind=='Program':
                compilation=run(['javac','-encoding','UTF-8','-d',str(td),str(copied)])
                if compilation is None or compilation.returncode!=0: return {'problem':pid,'status':'CE','error':compilation.stderr if compilation else 'compile timed out'}
                testcase=(problem_dir/t.get('input_file',t.get('fixture_file'))).read_text()
                args=['java','-cp',str(td),'Main']
                if t.get('input_delivery')=='write_fixture_to_temp_file_and_pass_path_as_args0':
                    data=td/'fixture.txt';data.write_text(testcase);args.append(str(data));testcase=''
                execute=run(args,input=testcase)
            else:
                snippet=(problem_dir/t['harness_snippet']).read_text()
                harness='import java.util.*;import java.nio.file.*;public class Harness {'+FORMATTING+'public static void main(String[]args) throws Exception {'+snippet+'}}'
                (td/'Harness.java').write_text(harness)
                compilation=run(['javac','-encoding','UTF-8','-d',str(td),str(copied),str(td/'Harness.java')])
                if compilation is None or compilation.returncode!=0:
                    return {'problem':pid,'status':'CE','error':compilation.stderr if compilation else 'compile timed out'}
                execute=run(['java','-cp',str(td),'Harness'])
            expected=(problem_dir/t['expected_file']).read_text().replace('\r\n','\n')
            if execute is None: verdict='TLE'
            elif execute.returncode!=0: verdict='RE'
            else: verdict='AC' if execute.stdout.replace('\r\n','\n')==expected else 'WA'
            judged.append({'test_id':t['id'],'visibility':t['visibility'],'verdict':verdict,'weight':t['weight']})
    return {'problem':pid,'status':'AC' if all(z['verdict']=='AC' for z in judged) else 'WA','score':round(sum(z['weight'] for z in judged if z['verdict']=='AC'),4),'tests':judged}

def main():
    parser=argparse.ArgumentParser(description='Trusted offline verification only; never execute untrusted student submissions on host')
    parser.add_argument('--problem',help='Problem id such as JAVA001');parser.add_argument('--all',action='store_true')
    parser.add_argument('--candidate',help='Run alternative JAVA FILE ONLY if you TRUST the source (unsafe on host)')
    args=parser.parse_args()
    if args.candidate: print('WARNING: Candidate code executes on your host WITHOUT sandbox isolation.',file=sys.stderr)
    ids=[p['id'] for p in json.loads((ROOT/'manifest.json').read_text())['problems']] if args.all else [args.problem]
    if not all(ids):parser.error('Specify --problem or --all')
    outcomes=[verify(p,args.candidate) for p in ids]
    for x in outcomes:print(x['problem'],x['status'],x.get('score',''),len(x.get('tests',[])))
    if len(outcomes)==1:print(json.dumps(outcomes[0],ensure_ascii=False,indent=2))
    sys.exit(0 if all(x['status']=='AC' for x in outcomes) else 1)
if __name__=='__main__':main()
