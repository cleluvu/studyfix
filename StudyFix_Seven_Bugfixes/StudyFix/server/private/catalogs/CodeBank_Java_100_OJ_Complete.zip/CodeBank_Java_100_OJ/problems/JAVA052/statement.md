# Kiểm tra hai chuỗi anagram

**Mã bài:** JAVA052  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static boolean isAnagram(String a,String b) kiểm tra hai chuỗi có cùng đa tập chữ cái ASCII, bỏ qua khoảng trắng và không phân biệt hoa thường.

## Ràng buộc và trường hợp biên

Không xét dấu câu, input chỉ chữ cái và khoảng trắng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static boolean isAnagram(String a,String b)
```
