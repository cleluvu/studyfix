# Kiểm tra dữ liệu tuổi

**Mã bài:** JAVA090  
**Week:** 11 – Ngoại lệ và tệp tin  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class UserProfile với private int age; constructor và setAge(int) ném IllegalArgumentException nếu tuổi ngoài [0,150].

## Ràng buộc và trường hợp biên

Có getter getAge().

## Quy ước kiểm thử bổ sung

Tuổi hợp lệ là từ 0 đến 150, bao gồm hai đầu; ngoài phạm vi ném IllegalArgumentException.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
