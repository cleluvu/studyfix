import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static long sum(int[] a) {long n=0;for(int x:a)n+=x;return n;}}
