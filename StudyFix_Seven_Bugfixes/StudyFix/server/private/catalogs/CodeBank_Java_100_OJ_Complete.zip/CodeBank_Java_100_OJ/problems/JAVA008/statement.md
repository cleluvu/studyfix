# Khoảng cách hai điểm

**Mã bài:** JAVA008  
**Week:** 1 – Java căn bản  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc x1,y1,x2,y2 là bốn số thực; tính khoảng cách Euclid của hai điểm trên mặt phẳng; xuất 4 chữ số thập phân.

## Ràng buộc và trường hợp biên

Hai điểm có thể trùng nhau.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
