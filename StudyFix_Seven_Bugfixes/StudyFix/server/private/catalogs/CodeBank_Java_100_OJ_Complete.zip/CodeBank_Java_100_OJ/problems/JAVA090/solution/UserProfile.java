import java.util.*;import java.nio.file.*;import java.io.*;
public class UserProfile {private int age;public UserProfile(int age){setAge(age);}public int getAge(){return age;}public void setAge(int age){if(age<0||age>150)throw new IllegalArgumentException();this.age=age;}}
