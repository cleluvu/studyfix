# Nén chuỗi run-length

**Mã bài:** JAVA053  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc một chuỗi ASCII không chứa khoảng trắng; in dạng ký tự rồi số lần lặp liên tiếp, ví dụ aaabb thành a3b2.

## Ràng buộc và trường hợp biên

Chuỗi rỗng in dòng rỗng.

## Quy ước kiểm thử bổ sung

Chuỗi đầu vào có thể rỗng; khi rỗng xuất một dòng trống.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
