import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int digitSum(long n) {return n<10?(int)n:(int)(n%10)+digitSum(n/10);}}
