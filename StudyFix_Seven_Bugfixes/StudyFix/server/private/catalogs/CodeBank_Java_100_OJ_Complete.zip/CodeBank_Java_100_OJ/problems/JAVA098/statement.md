# Tìm đường đi ngắn nhất trên lưới

**Mã bài:** JAVA098  
**Week:** 12 – Thuật toán và bài tổng hợp  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc r,c và lưới 0/1 (0 đi được,1 chắn); tìm số bước ít nhất từ ô (0,0) tới (r-1,c-1) bằng 4 hướng, in -1 nếu không tới.

## Ràng buộc và trường hợp biên

r,c <=200; BFS.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
