import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int findMax(int[] a) {int x=a[0];for(int v:a)x=Math.max(x,v);return x;}}
