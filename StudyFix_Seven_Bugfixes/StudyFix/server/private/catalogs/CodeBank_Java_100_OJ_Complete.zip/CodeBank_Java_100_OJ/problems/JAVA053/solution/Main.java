import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);String s=sc.hasNext()?sc.next():"";StringBuilder b=new StringBuilder();for(int i=0;i<s.length();){int j=i+1;while(j<s.length()&&s.charAt(j)==s.charAt(i))j++;b.append(s.charAt(i)).append(j-i);i=j;}System.out.println(b);}
}
