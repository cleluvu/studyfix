# Hoán đổi hai biến

**Mã bài:** JAVA004  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc hai số nguyên a, b; in hai số sau khi hoán đổi vị trí, cách nhau một dấu cách.

## Ràng buộc và trường hợp biên

Có thể dùng biến tạm.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
