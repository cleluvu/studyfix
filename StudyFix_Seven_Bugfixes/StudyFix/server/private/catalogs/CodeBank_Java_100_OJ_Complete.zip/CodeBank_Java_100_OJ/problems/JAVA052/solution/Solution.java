import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static boolean isAnagram(String a,String b) {int[]v=new int[26];for(char c:a.toLowerCase(java.util.Locale.ROOT).toCharArray())if(c!=32)v[c-97]++;for(char c:b.toLowerCase(java.util.Locale.ROOT).toCharArray())if(c!=32)v[c-97]--;for(int x:v)if(x!=0)return false;return true;}}
