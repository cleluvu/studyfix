# Xóa phần tử theo giá trị

**Mã bài:** JAVA034  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n, n số nguyên và x; in số lượng phần tử còn lại và dãy sau khi loại tất cả phần tử bằng x.

## Ràng buộc và trường hợp biên

Giữ nguyên thứ tự tương đối.

## Quy ước kiểm thử bổ sung

Nếu không còn phần tử, dòng thứ hai là dòng rỗng.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
