# Thống kê số dòng tệp

**Mã bài:** JAVA092  
**Week:** 11 – Ngoại lệ và tệp tin  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Nhận đường dẫn file UTF-8 qua args[0]; in số dòng vật lý của tệp.

## Ràng buộc và trường hợp biên

Tệp rỗng có 0 dòng; không truy cập file ngoài sandbox.

## Quy ước kiểm thử bổ sung

Đếm dòng vật lý theo Files.readAllLines, kể cả dòng cuối không có newline.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
