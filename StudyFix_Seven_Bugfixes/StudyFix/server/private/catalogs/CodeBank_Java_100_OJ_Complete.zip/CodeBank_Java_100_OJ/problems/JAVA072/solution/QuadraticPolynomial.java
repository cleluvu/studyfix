import java.util.*;import java.nio.file.*;import java.io.*;
public class QuadraticPolynomial {private double a,b,c;public QuadraticPolynomial(double a,double b,double c){this.a=a;this.b=b;this.c=c;}public double valueAt(double x){return (a*x+b)*x+c;}public int rootsCount(){if(a==0){return b==0?(c==0?-1:0):1;}double d=b*b-4*a*c;return d>0?2:d==0?1:0;}}
