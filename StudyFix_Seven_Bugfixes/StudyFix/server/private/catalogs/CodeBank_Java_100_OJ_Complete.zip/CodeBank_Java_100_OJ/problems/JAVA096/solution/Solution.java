import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int binarySearchFirst(int[] a,int x) {int l=0,r=a.length;while(l<r){int m=(l+r)>>>1;if(a[m]<x)l=m+1;else r=m;}return l<a.length&&a[l]==x?l:-1;}}
