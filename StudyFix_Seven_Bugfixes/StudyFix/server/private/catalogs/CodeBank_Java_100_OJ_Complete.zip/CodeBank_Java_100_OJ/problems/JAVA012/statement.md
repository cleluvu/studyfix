# Kiểm tra năm nhuận

**Mã bài:** JAVA012  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc năm nguyên dương; in LEAP nếu chia hết 400 hoặc chia hết 4 nhưng không chia hết 100; ngược lại in COMMON.

## Ràng buộc và trường hợp biên

Dùng quy tắc lịch Gregory.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
