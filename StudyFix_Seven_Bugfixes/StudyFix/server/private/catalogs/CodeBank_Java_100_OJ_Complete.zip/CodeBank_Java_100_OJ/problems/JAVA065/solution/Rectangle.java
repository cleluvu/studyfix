import java.util.*;import java.nio.file.*;import java.io.*;
public class Rectangle {private double width,height;public Rectangle(double width,double height){this.width=width;this.height=height;}public double getWidth(){return width;}public double getHeight(){return height;}public double area(){return width*height;}public double perimeter(){return 2*(width+height);}}
