# Hệ thống thông báo đa hình

**Mã bài:** JAVA080  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Định nghĩa interface Notification với String send(); EmailNotification(address) và SmsNotification(phone) cài đặt send() trả EMAIL:address và SMS:phone.

## Ràng buộc và trường hợp biên

Không thực sự gửi tin nhắn.

## Quy ước kiểm thử bổ sung

EmailNotification.send() trả "EMAIL:" nối address; SmsNotification.send() trả "SMS:" nối phone.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
