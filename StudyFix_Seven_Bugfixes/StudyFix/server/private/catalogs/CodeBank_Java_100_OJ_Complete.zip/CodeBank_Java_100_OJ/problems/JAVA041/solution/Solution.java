import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static long mainDiagonalSum(int[][] a) {long s=0;for(int i=0;i<a.length;i++)s+=a[i][i];return s;}}
