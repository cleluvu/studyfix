# Đảo ngược mảng tại chỗ

**Mã bài:** JAVA031  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static void reverse(int[] a), đổi thứ tự các phần tử ngay trên mảng đầu vào.

## Ràng buộc và trường hợp biên

Không được tạo mảng kết quả thứ hai.

## Quy ước kiểm thử bổ sung

Không trả về giá trị; bộ chấm kiểm tra mảng đầu vào sau khi gọi reverse.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static void reverse(int[] a)
```
