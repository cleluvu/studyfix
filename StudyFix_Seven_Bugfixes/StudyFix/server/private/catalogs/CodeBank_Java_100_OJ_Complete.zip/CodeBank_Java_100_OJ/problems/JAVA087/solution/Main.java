import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();java.util.Deque<String> q=new java.util.ArrayDeque<>();for(int i=0;i<n;i++){String op=sc.next();if(op.equals("PUSH"))q.addLast(sc.next());else if(op.equals("POP")){if(q.isEmpty())System.out.println("EMPTY");else q.removeFirst();}else if(op.equals("FRONT"))System.out.println(q.isEmpty()?"EMPTY":q.peekFirst());}}
}
