import java.util.*;import java.nio.file.*;import java.io.*;
public class Box<T> {private T value;public Box(T value){this.value=value;}public T get(){return value;}public void set(T v){value=v;}public boolean isEmpty(){return value==null;}}
