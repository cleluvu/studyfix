abstract class Shape {public abstract double area();}
public class Solution {
    public static double totalArea(Shape[] shapes) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
