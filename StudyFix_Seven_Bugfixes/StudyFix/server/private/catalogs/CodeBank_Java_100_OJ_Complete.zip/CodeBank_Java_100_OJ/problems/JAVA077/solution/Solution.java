import java.util.*;import java.nio.file.*;import java.io.*;
abstract class Shape {public abstract double area();}
public class Solution {public static double totalArea(Shape[] shapes) {double sum=0;for(Shape s:shapes)sum+=s.area();return sum;}}
