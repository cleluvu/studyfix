# Phần tử lớn thứ hai phân biệt

**Mã bài:** JAVA032  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n>=2 và mảng nguyên; in giá trị lớn thứ hai khác giá trị lớn nhất, hoặc NONE nếu không tồn tại.

## Ràng buộc và trường hợp biên

Có thể có nhiều phần tử trùng.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
