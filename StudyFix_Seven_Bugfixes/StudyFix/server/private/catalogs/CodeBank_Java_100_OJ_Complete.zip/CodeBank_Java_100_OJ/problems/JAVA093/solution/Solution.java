import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static void saveNames(java.nio.file.Path path,java.util.List<String> names) {try{java.nio.file.Files.write(path,names,java.nio.charset.StandardCharsets.UTF_8);}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}}}
