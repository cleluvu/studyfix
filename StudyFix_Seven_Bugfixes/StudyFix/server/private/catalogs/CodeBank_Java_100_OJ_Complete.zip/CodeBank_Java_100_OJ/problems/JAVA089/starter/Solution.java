public class Solution {
    public static int safeDivide(int a,int b) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
