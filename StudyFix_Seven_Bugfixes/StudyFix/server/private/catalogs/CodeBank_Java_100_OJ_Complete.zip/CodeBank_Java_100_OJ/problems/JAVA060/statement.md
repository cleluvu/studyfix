# Đệ quy tính tổng chữ số

**Mã bài:** JAVA060  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int digitSum(long n) bằng đệ quy.

## Ràng buộc và trường hợp biên

n không âm.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int digitSum(long n)
```
