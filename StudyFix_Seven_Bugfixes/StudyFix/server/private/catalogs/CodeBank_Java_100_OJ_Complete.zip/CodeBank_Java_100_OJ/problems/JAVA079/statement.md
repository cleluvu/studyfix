# Interface Comparable cho Product

**Mã bài:** JAVA079  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo Product(name,price) implements Comparable<Product>; sắp theo price tăng, nếu bằng thì theo name từ điển.

## Ràng buộc và trường hợp biên

Price không âm.

## Quy ước kiểm thử bổ sung

Product(String name,double price), getName(),getPrice(), compareTo(Product) theo price tăng, name tăng.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
