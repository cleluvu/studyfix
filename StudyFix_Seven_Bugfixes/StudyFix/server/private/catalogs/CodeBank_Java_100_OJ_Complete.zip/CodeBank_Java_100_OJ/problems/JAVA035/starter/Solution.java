public class Solution {
    public static int[] mergeSorted(int[] a,int[] b) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
