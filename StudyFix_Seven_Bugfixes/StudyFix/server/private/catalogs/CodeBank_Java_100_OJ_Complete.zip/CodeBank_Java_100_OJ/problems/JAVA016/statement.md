# Máy tính bốn phép toán

**Mã bài:** JAVA016  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc hai số thực và ký tự toán tử +,-,*,/; in kết quả với 2 chữ số hoặc ERROR khi chia 0 hay toán tử không hợp lệ.

## Ràng buộc và trường hợp biên

Đảm bảo không chia cho 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
