import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static void reverse(int[] a) {for(int i=0,j=a.length-1;i<j;i++,j--){int t=a[i];a[i]=a[j];a[j]=t;}}}
