# Method đếm số nguyên tố

**Mã bài:** JAVA056  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int countPrimes(int[] a), đếm phần tử là số nguyên tố.

## Ràng buộc và trường hợp biên

Giá trị âm và 0,1 không nguyên tố.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int countPrimes(int[] a)
```
