import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);double a=sc.nextDouble(),b=sc.nextDouble();String op=sc.next();if(op.equals("/")&&b==0){System.out.println("ERROR");}else {double r=0;boolean ok=true;switch(op){case "+":r=a+b;break;case "-":r=a-b;break;case "*":r=a*b;break;case "/":r=a/b;break;default:ok=false;}if(ok)System.out.printf(java.util.Locale.ROOT,"%.2f%n",r);else System.out.println("ERROR");}}
}
