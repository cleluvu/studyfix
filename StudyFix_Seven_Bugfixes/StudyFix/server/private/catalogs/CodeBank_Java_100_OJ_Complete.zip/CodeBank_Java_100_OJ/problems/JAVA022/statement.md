# Kiểm tra số nguyên tố

**Mã bài:** JAVA022  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc số nguyên n; in YES nếu n nguyên tố, ngược lại NO.

## Ràng buộc và trường hợp biên

n nhỏ hơn 2 không phải nguyên tố; kiểm tra tới căn bậc hai.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
