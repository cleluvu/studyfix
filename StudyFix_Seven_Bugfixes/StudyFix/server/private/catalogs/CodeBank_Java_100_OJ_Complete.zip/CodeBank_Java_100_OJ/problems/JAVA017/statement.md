# Tính tổng từ 1 đến n

**Mã bài:** JAVA017  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n nguyên không âm; in tổng 1+2+...+n.

## Ràng buộc và trường hợp biên

n=0 cho kết quả 0; tránh tràn số với kiểu long.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
