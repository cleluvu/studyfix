# Bảng xếp hạng điểm lập trình

**Mã bài:** JAVA100  
**Week:** 12 – Thuật toán và bài tổng hợp  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n bản ghi name score penalty; sắp theo score giảm, penalty tăng, name từ điển tăng; in thứ hạng và tên mỗi dòng.

## Ràng buộc và trường hợp biên

Tên không có whitespace, 1<=n<=10^5.

## Quy ước kiểm thử bổ sung

Mỗi dòng output gồm name score penalty, cách nhau một dấu cách.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
