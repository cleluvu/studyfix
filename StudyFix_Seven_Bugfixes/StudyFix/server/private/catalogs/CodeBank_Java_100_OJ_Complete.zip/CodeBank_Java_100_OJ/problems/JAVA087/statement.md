# Hàng đợi xử lý yêu cầu

**Mã bài:** JAVA087  
**Week:** 10 – Collections và Generics  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc q lệnh PUSH x, POP, FRONT; dùng queue để xử lý; với POP/FRONT khi rỗng in EMPTY, với POP không rỗng in phần tử bị xóa.

## Ràng buộc và trường hợp biên

Giữ FIFO; số lệnh tới 10^5.

## Quy ước kiểm thử bổ sung

POP chỉ loại bỏ phần tử, không in kết quả nếu hàng đợi không rỗng.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
