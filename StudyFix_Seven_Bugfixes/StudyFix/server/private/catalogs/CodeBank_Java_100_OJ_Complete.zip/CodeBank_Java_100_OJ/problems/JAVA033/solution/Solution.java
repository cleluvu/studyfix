import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static boolean isPalindrome(int[] a) {for(int i=0,j=a.length-1;i<j;i++,j--)if(a[i]!=a[j])return false;return true;}}
