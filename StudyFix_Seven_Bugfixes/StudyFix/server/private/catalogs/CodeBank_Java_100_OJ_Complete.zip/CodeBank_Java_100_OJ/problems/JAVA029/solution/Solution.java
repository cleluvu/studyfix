import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int countEven(int[] a) {int s=0;for(int v:a)if(v%2==0)s++;return s;}}
