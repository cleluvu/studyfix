# Nhóm sản phẩm theo loại

**Mã bài:** JAVA086  
**Week:** 10 – Collections và Generics  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static Map<String,List<String>> group(List<Product> products), gom tên sản phẩm theo category của mỗi Product.

## Ràng buộc và trường hợp biên

Product có getCategory(), getName(); giữ thứ tự xuất hiện trong từng nhóm.

## Quy ước kiểm thử bổ sung

Product helper có public fields String category,name; constructor Product(String category,String name); thứ tự tên giữ theo đầu vào.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static java.util.Map<String,java.util.List<String>> group(java.util.List<Product> products)
```
