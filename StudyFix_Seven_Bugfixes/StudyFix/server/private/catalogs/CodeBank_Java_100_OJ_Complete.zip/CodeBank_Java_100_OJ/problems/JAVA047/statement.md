# Đảo ngược chuỗi

**Mã bài:** JAVA047  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static String reverseText(String s), đảo thứ tự ký tự theo đơn vị Unicode code point.

## Ràng buộc và trường hợp biên

Chuỗi có thể rỗng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static String reverseText(String s)
```
