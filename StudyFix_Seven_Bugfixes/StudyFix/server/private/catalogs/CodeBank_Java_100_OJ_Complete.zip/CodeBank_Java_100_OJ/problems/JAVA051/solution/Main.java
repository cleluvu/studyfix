import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);String s=sc.hasNextLine()?sc.nextLine():"";int[]a=new int[26];for(char ch:s.toCharArray())a[ch-97]++;for(int i=0;i<26;i++){if(i>0)System.out.print(" ");System.out.print(a[i]);}System.out.println();}
}
