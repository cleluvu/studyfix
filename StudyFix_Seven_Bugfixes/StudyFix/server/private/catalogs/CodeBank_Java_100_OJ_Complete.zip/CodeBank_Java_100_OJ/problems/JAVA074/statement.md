# Kế thừa Employee và Manager

**Mã bài:** JAVA074  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo Employee(baseSalary) với salary(); Manager extends Employee thêm allowance, override salary() trả baseSalary+allowance.

## Ràng buộc và trường hợp biên

Các giá trị không âm.

## Quy ước kiểm thử bổ sung

Employee(double baseSalary), Manager(double baseSalary,double allowance), salary() trả tổng.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
