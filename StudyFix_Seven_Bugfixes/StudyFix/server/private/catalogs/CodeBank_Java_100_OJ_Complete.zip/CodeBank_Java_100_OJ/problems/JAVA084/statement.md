# Sắp xếp sinh viên theo điểm

**Mã bài:** JAVA084  
**Week:** 10 – Collections và Generics  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n dòng gồm mã SV và điểm; in danh sách mã theo điểm giảm, nếu bằng theo mã tăng.

## Ràng buộc và trường hợp biên

Mã không chứa whitespace.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
