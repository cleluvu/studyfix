# Đệ quy tính lũy thừa

**Mã bài:** JAVA059  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static long power(long a,int n) trả a^n bằng đệ quy chia để trị.

## Ràng buộc và trường hợp biên

n>=0; dữ liệu bảo đảm kết quả trong phạm vi long.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static long power(long a,int n)
```
