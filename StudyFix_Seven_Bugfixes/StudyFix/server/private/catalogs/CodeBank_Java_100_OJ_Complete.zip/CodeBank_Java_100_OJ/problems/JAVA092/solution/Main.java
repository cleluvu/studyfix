import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);System.out.println(java.nio.file.Files.readAllLines(java.nio.file.Path.of(args[0]),java.nio.charset.StandardCharsets.UTF_8).size());}
}
