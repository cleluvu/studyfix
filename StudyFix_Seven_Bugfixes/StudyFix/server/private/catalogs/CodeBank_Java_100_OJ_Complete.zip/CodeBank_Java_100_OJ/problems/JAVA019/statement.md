# Đếm chữ số của số nguyên

**Mã bài:** JAVA019  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc một số nguyên 64-bit; in số chữ số thập phân của trị tuyệt đối.

## Ràng buộc và trường hợp biên

Số 0 có 1 chữ số; cân nhắc Long.MIN_VALUE.

## Quy ước kiểm thử bổ sung

Dấu âm không tính là chữ số. Đầu vào là một giá trị long duy nhất.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
