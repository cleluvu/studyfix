# Lớp Fraction

**Mã bài:** JAVA068  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo public class Fraction với tử/mẫu số nguyên; chuẩn hóa dấu và rút gọn tại constructor; có add(Fraction) và toString() dạng a/b.

## Ràng buộc và trường hợp biên

Mẫu khác 0; 0 biểu diễn 0/1.

## Quy ước kiểm thử bổ sung

Sử dụng Fraction(long numerator,long denominator); getNumerator/getDenominator trả long; add(Fraction) trả Fraction; toString() có dạng numerator/denominator.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
