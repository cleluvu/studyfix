import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static boolean isSymmetric(int[][] a) {for(int i=0;i<a.length;i++)for(int j=i+1;j<a.length;j++)if(a[i][j]!=a[j][i])return false;return true;}}
