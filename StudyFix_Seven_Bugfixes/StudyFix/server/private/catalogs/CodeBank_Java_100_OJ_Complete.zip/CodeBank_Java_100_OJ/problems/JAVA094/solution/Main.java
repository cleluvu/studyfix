import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);java.util.List<String> lines=java.nio.file.Files.readAllLines(java.nio.file.Path.of(args[0]),java.nio.charset.StandardCharsets.UTF_8);double sum=0;int n=0;for(int i=1;i<lines.size();i++)if(!lines.get(i).isBlank()){String[]f=lines.get(i).split(",",-1);sum+=Double.parseDouble(f[2]);n++;}System.out.printf(java.util.Locale.ROOT,"%.2f%n",n==0?0:sum/n);}
}
