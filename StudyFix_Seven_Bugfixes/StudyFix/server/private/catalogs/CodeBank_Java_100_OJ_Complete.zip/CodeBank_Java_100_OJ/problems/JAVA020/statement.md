# Đảo ngược chữ số

**Mã bài:** JAVA020  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc số nguyên không âm n, in các chữ số của n theo thứ tự đảo dưới dạng số nguyên.

## Ràng buộc và trường hợp biên

Các số 0 đứng đầu sau khi đảo không được in.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
