# Đếm nguyên âm trong chuỗi

**Mã bài:** JAVA046  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int countVowels(String s), đếm các ký tự a,e,i,o,u không phân biệt hoa thường.

## Ràng buộc và trường hợp biên

Chỉ tính nguyên âm Latin cơ bản.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int countVowels(String s)
```
