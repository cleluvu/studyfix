# Sinh chuỗi nhị phân độ dài n

**Mã bài:** JAVA062  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n thuộc [0,16]; in toàn bộ chuỗi nhị phân độ dài n theo thứ tự từ điển, mỗi chuỗi một dòng.

## Ràng buộc và trường hợp biên

n=0 in một dòng rỗng.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
