# Tìm từ xuất hiện nhiều nhất

**Mã bài:** JAVA054  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc một dòng gồm các từ ASCII cách bởi whitespace; in từ có tần suất lớn nhất (không phân biệt hoa thường), nếu hòa chọn từ nhỏ nhất theo từ điển.

## Ràng buộc và trường hợp biên

Không có dấu câu; dòng rỗng in NONE.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
