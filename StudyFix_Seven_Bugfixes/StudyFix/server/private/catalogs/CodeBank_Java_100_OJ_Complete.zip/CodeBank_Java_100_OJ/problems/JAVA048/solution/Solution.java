import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static boolean isPalindrome(String s) {String t=s.replaceAll("\\s+","").toLowerCase(java.util.Locale.ROOT);return t.contentEquals(new StringBuilder(t).reverse());}}
