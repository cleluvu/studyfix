# Kiểm tra mảng đối xứng

**Mã bài:** JAVA033  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static boolean isPalindrome(int[] a) cho biết mảng đọc từ trái sang phải có bằng đọc ngược hay không.

## Ràng buộc và trường hợp biên

Mảng 0 hoặc 1 phần tử là đối xứng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static boolean isPalindrome(int[] a)
```
