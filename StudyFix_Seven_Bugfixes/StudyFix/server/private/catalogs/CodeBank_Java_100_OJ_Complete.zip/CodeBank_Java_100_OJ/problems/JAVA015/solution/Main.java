import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int age=sc.nextInt();double p=sc.nextDouble();System.out.printf(java.util.Locale.ROOT,"%.2f%n",p*(age<6?0:age<18?.5:age>=60?.7:1));}
}
