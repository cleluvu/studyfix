# Loại bỏ phần tử trùng List

**Mã bài:** JAVA081  
**Week:** 10 – Collections và Generics  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static List<Integer> unique(List<Integer> a) trả danh sách phần tử không trùng theo thứ tự xuất hiện đầu tiên.

## Ràng buộc và trường hợp biên

Không sửa list đầu vào.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static java.util.List<Integer> unique(java.util.List<Integer> a)
```
