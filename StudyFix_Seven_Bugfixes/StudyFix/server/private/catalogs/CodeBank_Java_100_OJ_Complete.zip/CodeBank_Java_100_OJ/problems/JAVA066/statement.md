# Lớp Circle

**Mã bài:** JAVA066  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo public class Circle với bán kính private double radius, constructor, getter/setter và phương thức area(), circumference().

## Ràng buộc và trường hợp biên

Setter từ chối radius âm bằng IllegalArgumentException.

## Quy ước kiểm thử bổ sung

Constructor sử dụng setRadius; bán kính âm phải ném IllegalArgumentException.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
