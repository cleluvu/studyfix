public class Solution {
    public static boolean isPalindrome(int[] a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
