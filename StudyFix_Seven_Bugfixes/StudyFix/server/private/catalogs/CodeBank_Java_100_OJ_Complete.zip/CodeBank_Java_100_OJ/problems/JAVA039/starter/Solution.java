public class Solution {
    public static int maxMatrix(int[][] a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
