import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int safeDivide(int a,int b) {if(b==0)throw new IllegalArgumentException("division by zero");return a/b;}}
