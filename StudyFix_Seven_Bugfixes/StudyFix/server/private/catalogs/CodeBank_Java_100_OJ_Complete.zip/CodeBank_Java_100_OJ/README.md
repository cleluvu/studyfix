# CodeBank – 100 bài Java theo Week (OJ data package)

Bộ này được sinh từ JSON 100 bài do người dùng cung cấp, giữ nguyên 100 ID và 12 Week, KHÔNG có Category. Tổng 50 Program, 30 Method, 20 Class.

Mỗi bài chứa `problem.json`, `statement.md`, `starter/`, `solution/`, `judge_config.json`, `tests/public`, `tests/hidden`. Dữ liệu `solution` và `tests/hidden` là **teacher/judge-only**, không bao giờ được gửi cho sinh viên.

## Thực trạng kiểm thử

- Lời giải tham chiếu được biên dịch bằng OpenJDK 21, sử dụng cú pháp tương thích Java 17 và chạy đối chiếu output của các fixture.
- Có 314 fixture (public và hidden). Đây là một bộ kiểm thử khởi đầu; chưa đủ để khẳng định phủ hết mọi lỗi của mọi bài.
- Kết quả `reference_run` chỉ là kiểm thử offline, không chứng minh đã tích hợp và chạy sandbox trong CodeBank.
- Những hợp đồng API của bài Class chưa được phát biểu đầy đủ trong JSON gốc đã được bổ sung ở cuối đề bài, cần giảng viên duyệt lại.
- `starter/` của bài Class là khung class/interface; sinh viên cần triển khai các API như đề yêu cầu.
- Mọi bài có `status: draft`, `validation_status: pending` trước khi tích hợp, để tránh công bố bài chưa được duyệt.

## Kiểm thử nhanh (CHỈ cho lời giải tin cậy)

```bash
python verify_reference.py --problem JAVA028
python verify_reference.py --problem JAVA064
python verify_reference.py --all
```

**Không chạy `verify_reference.py` với code sinh viên chưa tin cậy.** Đây là công cụ test offline không sandbox. Mọi code của sinh viên phải được chạy trong judge container cách ly với mạng, filesystem, CPU, RAM, process và time limits.

## Lưu ý khi import

- Dùng `manifest.json` + `weeks.json`; map trực tiếp vào Week hiện có, không tạo Category.
- Upsert theo `id` và `version` hoặc skip khi có mã trùng; import theo transaction/batch, giữ nguyên database cũ.
- Không public thư mục `solution` hay `tests/hidden`, kể cả link tĩnh.
- Program: stdin/stdout; riêng JAVA091, JAVA092, JAVA094 sử dụng file fixture tạo trong sandbox rồi truyền đường dẫn qua `args[0]`.
- Method/Class: các `*.java.snippet` là những đoạn statement trong trusted harness; không phải JUnit file hoàn chỉnh. Importer cần dựng harness có helper `fmt`, biên dịch cùng bài nộp, so sánh stdout với `*.expected`; khuyến nghị chuyển đổi sang JUnit trong Judge production.
- Cấu hình trong `judge_config.json` là format nội bộ đề xuất, importer phải ánh xạ theo API/schema thực của project.
- Test case được phân bổ 100 điểm mỗi bài, cho phép chấm điểm từng phần.
