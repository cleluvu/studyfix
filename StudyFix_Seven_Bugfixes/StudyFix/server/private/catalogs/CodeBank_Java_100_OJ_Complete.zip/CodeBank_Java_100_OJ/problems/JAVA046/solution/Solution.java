import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int countVowels(String s) {int n=0;for(char c:s.toLowerCase(java.util.Locale.ROOT).toCharArray())if("aeiou".indexOf(c)>=0)n++;return n;}}
