# Lớp Polynomial bậc hai

**Mã bài:** JAVA072  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class QuadraticPolynomial chứa a,b,c thực; method valueAt(double x) và rootsCount() trả 0,1,2 hoặc -1 khi a=b=c=0.

## Ràng buộc và trường hợp biên

Nếu a=0 xử lý phương trình tuyến tính.

## Quy ước kiểm thử bổ sung

Khi a==0, bài toán chuyển thành tuyến tính. Nếu a==b==c==0 thì rootsCount() trả -1 đại diện vô số nghiệm.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
