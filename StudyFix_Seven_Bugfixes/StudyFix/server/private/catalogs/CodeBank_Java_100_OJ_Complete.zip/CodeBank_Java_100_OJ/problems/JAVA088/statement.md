# Generic Box

**Mã bài:** JAVA088  
**Week:** 10 – Collections và Generics  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class Box<T> với constructor Box(T), get(), set(T), isEmpty() trả true nếu giá trị null.

## Ràng buộc và trường hợp biên

Không sử dụng raw type.

## Quy ước kiểm thử bổ sung

Box<T> constructor Box(T), get(),set(T),isEmpty().

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
