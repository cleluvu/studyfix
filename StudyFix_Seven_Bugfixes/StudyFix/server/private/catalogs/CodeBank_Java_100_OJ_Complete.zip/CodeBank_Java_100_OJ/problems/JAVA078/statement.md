# Override equals cho Point

**Mã bài:** JAVA078  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo immutable class Point có x,y int; cài đặt equals(Object) và hashCode() theo tọa độ, toString() dạng (x,y).

## Ràng buộc và trường hợp biên

Hai point bằng nhau khi x,y giống nhau.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
