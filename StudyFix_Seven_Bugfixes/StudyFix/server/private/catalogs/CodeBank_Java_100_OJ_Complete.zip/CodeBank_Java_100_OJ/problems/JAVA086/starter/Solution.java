class Product {public String category,name;public Product(String c,String n){category=c;name=n;}}
public class Solution {
    public static java.util.Map<String,java.util.List<String>> group(java.util.List<Product> products) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
