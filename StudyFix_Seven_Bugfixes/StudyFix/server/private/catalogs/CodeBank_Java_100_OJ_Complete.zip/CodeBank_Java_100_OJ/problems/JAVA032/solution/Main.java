import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int n=sc.nextInt();Integer x=null,y=null;for(int i=0;i<n;i++){int v=sc.nextInt();if(x==null||v>x){if(x!=null&&!x.equals(v))y=x;x=v;}else if(v<x&&(y==null||v>y))y=v;}System.out.println(y==null?"NONE":y);}
}
