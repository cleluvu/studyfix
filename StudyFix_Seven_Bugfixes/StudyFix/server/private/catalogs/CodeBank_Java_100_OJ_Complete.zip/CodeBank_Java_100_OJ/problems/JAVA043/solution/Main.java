import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int r=sc.nextInt(),c=sc.nextInt();long[][]a=new long[r][c];for(int i=0;i<r;i++)for(int j=0;j<c;j++)a[i][j]=sc.nextLong();int x=sc.nextInt(),y=sc.nextInt();long[][]b=new long[x][y];for(int i=0;i<x;i++)for(int j=0;j<y;j++)b[i][j]=sc.nextLong();if(c!=x)System.out.println("INVALID");else{for(int i=0;i<r;i++){for(int j=0;j<y;j++){long s=0;for(int k=0;k<c;k++)s+=a[i][k]*b[k][j];if(j>0)System.out.print(" ");System.out.print(s);}System.out.println();}}}
}
