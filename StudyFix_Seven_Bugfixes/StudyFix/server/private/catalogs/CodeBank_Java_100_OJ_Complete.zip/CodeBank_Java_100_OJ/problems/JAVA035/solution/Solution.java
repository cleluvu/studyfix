import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int[] mergeSorted(int[] a,int[] b) {int[]o=new int[a.length+b.length];int i=0,j=0,k=0;while(i<a.length||j<b.length){if(j==b.length||(i<a.length&&a[i]<=b[j]))o[k++]=a[i++];else o[k++]=b[j++];}return o;}}
