import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);double a=sc.nextDouble(),b=sc.nextDouble(),c=sc.nextDouble();System.out.println(a<=0||b<=0||c<=0||a+b<=c||a+c<=b||b+c<=a?"INVALID":a==b&&b==c?"EQUILATERAL":a==b||a==c||b==c?"ISOSCELES":"SCALENE");}
}
