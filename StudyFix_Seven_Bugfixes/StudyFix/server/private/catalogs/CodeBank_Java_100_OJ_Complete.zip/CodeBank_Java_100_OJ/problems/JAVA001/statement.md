# Tính tổng và hiệu hai số

**Mã bài:** JAVA001  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc hai số nguyên a, b; in tổng a+b và hiệu a-b trên hai dòng riêng.

## Ràng buộc và trường hợp biên

Cho phép số âm và số 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
