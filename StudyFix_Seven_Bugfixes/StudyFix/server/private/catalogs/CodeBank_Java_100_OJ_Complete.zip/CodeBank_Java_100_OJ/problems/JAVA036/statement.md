# Độ dài dãy tăng liên tiếp

**Mã bài:** JAVA036  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n và dãy nguyên; in độ dài lớn nhất của một đoạn liên tiếp tăng nghiêm ngặt.

## Ràng buộc và trường hợp biên

n=0 cho kết quả 0; yêu cầu O(n).

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
