import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static long gcd(long a,long b) {while(b!=0){long t=a%b;a=b;b=t;}return a;}}
