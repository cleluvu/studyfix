# Kiểm tra ngoặc cân bằng

**Mã bài:** JAVA097  
**Week:** 12 – Thuật toán và bài tổng hợp  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static boolean validBrackets(String s) kiểm tra (),[],{} đóng mở đúng thứ tự bằng stack.

## Ràng buộc và trường hợp biên

Bỏ qua ký tự khác ngoặc.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static boolean validBrackets(String s)
```
