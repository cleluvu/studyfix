# Đọc và cộng số từ tệp

**Mã bài:** JAVA091  
**Week:** 11 – Ngoại lệ và tệp tin  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Nhận đường dẫn file text qua args[0]; đọc các số nguyên phân tách whitespace trong tệp và in tổng kiểu long.

## Ràng buộc và trường hợp biên

Nếu file không tồn tại hoặc token sai in ERROR.

## Quy ước kiểm thử bổ sung

Chương trình nhận một đường dẫn file làm args[0]. File được judge tự dựng trong sandbox từ nội dung fixture.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
