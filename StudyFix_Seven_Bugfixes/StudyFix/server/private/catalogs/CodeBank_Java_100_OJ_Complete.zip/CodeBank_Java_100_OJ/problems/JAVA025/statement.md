# Dãy Fibonacci thứ n

**Mã bài:** JAVA025  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n thuộc [0,92]; in F(n) với F(0)=0, F(1)=1 bằng kiểu long.

## Ràng buộc và trường hợp biên

Không dùng kiểu int cho kết quả.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
