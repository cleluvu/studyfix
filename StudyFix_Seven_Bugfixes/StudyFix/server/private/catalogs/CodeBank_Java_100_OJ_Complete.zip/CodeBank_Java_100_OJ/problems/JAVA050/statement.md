# Đếm số từ trong câu

**Mã bài:** JAVA050  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc một dòng văn bản; in số từ, mỗi từ là đoạn liên tiếp các ký tự không phải whitespace.

## Ràng buộc và trường hợp biên

Dòng chỉ gồm khoảng trắng trả 0.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
