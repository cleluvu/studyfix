import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int maxMatrix(int[][] a) {int v=a[0][0];for(int[]row:a)for(int x:row)v=Math.max(v,x);return v;}}
