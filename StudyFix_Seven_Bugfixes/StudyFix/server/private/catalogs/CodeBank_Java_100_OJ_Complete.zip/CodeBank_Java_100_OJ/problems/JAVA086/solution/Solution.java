import java.util.*;import java.nio.file.*;import java.io.*;
class Product {public String category,name;public Product(String c,String n){category=c;name=n;}}
public class Solution {public static java.util.Map<String,java.util.List<String>> group(java.util.List<Product> products) {java.util.Map<String,java.util.List<String>> m=new java.util.TreeMap<>();for(Product p:products)m.computeIfAbsent(p.category,k->new java.util.ArrayList<>()).add(p.name);return m;}}
