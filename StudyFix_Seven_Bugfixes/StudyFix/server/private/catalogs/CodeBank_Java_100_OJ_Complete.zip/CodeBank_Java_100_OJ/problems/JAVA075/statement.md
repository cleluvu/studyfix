# Abstract Shape tính diện tích

**Mã bài:** JAVA075  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo abstract class Shape với abstract double area(); tạo CircleShape và RectangleShape kế thừa, hiện thực diện tích.

## Ràng buộc và trường hợp biên

Kích thước dương.

## Quy ước kiểm thử bổ sung

Shape trừu tượng có public abstract double area(); CircleShape(double r), RectangleShape(double w,double h).

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
