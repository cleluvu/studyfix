import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int r=sc.nextInt(),c=sc.nextInt();long[][]a=new long[r][c];for(int i=0;i<r;i++)for(int j=0;j<c;j++)a[i][j]=sc.nextLong();for(int j=0;j<c;j++){for(int i=0;i<r;i++){if(i>0)System.out.print(" ");System.out.print(a[i][j]);}System.out.println();}}
}
