# Đổi giây ra giờ phút giây

**Mã bài:** JAVA003  
**Week:** 1 – Java căn bản  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc số nguyên không âm s; đổi thành giờ, phút, giây và in ba số theo thứ tự.

## Ràng buộc và trường hợp biên

Xử lý s=0 và s lớn hơn 86400.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
