import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int r=sc.nextInt(),c=sc.nextInt();int[][]a=new int[r][c],d=new int[r][c];for(int i=0;i<r;i++)for(int j=0;j<c;j++){a[i][j]=sc.nextInt();d[i][j]=-1;}if(a[0][0]==1||a[r-1][c-1]==1){System.out.println(-1);return;}java.util.ArrayDeque<int[]>q=new java.util.ArrayDeque<>();q.add(new int[]{0,0});d[0][0]=0;int[]di={1,-1,0,0},dj={0,0,1,-1};while(!q.isEmpty()){int[]v=q.remove();for(int k=0;k<4;k++){int ni=v[0]+di[k],nj=v[1]+dj[k];if(ni>=0&&ni<r&&nj>=0&&nj<c&&a[ni][nj]==0&&d[ni][nj]<0){d[ni][nj]=d[v[0]][v[1]]+1;q.add(new int[]{ni,nj});}}}System.out.println(d[r-1][c-1]);}
}
