# Tháp Hà Nội

**Mã bài:** JAVA063  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n thuộc [1,12]; in số bước rồi liệt kê từng bước chuyển đĩa từ A sang C dùng B theo thứ tự đệ quy chuẩn.

## Ràng buộc và trường hợp biên

Mỗi bước có dạng A C.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
