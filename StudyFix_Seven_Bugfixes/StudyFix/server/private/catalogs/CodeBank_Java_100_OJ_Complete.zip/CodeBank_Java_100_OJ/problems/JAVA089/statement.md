# Ngoại lệ chia cho 0

**Mã bài:** JAVA089  
**Week:** 11 – Ngoại lệ và tệp tin  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int safeDivide(int a,int b) trả phép chia nguyên, ném IllegalArgumentException khi b=0.

## Ràng buộc và trường hợp biên

Phép chia theo quy tắc Java.

## Quy ước kiểm thử bổ sung

b==0 ném IllegalArgumentException; phép chia làm tròn về 0 như toán tử chia nguyên Java.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int safeDivide(int a,int b)
```
