import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);long n=sc.nextLong(),s= n==1?0:1;for(long i=2;i<=n/i;i++)if(n%i==0){s+=i;if(i!=n/i)s+=n/i;}System.out.println(n>1&&s==n?"YES":"NO");}
}
