public class Solution {
    public static boolean isPalindrome(String s,int left,int right) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
