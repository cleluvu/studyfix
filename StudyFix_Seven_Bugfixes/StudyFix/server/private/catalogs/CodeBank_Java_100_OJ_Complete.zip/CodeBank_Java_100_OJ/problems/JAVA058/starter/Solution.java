public class Solution {
    public static long gcd(long a,long b) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
