# Xếp loại điểm học phần

**Mã bài:** JAVA011  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc điểm thực từ 0 đến 10; in A nếu từ 8.5, B nếu từ 7, C nếu từ 5.5, D nếu từ 4 và F ở trường hợp còn lại.

## Ràng buộc và trường hợp biên

Điểm phải thuộc [0,10].

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
