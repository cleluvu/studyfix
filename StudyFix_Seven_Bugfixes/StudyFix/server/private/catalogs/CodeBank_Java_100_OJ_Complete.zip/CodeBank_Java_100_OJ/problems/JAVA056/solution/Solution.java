import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int countPrimes(int[] a) {int count=0;for(int x:a){if(x<2)continue;boolean ok=true;for(int i=2;i<=x/i;i++)if(x%i==0){ok=false;break;}if(ok)count++;}return count;}}
