# Ma trận đối xứng

**Mã bài:** JAVA042  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static boolean isSymmetric(int[][] a) kiểm tra a[i][j]==a[j][i].

## Ràng buộc và trường hợp biên

Ma trận đầu vào vuông.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static boolean isSymmetric(int[][] a)
```
