# PROMPT CODEX – IMPORT 100 BÀI JAVA OJ HOÀN CHỈNH VÀO CODEBANK

Bạn là Senior Full-stack / Java Online Judge Engineer. Tôi cung cấp gói `CodeBank_Java_100_OJ.zip` gồm 100 bài Java, 12 Week, 50 Program + 30 Method + 20 Class, các file đề bài, starter, lời giải chuẩn, test công khai/ẩn và judge_config. **Nhiệm vụ là tích hợp thật vào CodeBank đang chạy để học sinh có thể nộp và nhận AC, WA, CE, RE, TLE, MLE.** Không chỉ upload metadata hoặc làm giao diện mô phỏng.

## Nguyên tắc tuyệt đối

1. Trước tiên đọc toàn bộ source Backend, Database schema, frontend, API, auth, Week và judge. Kiểm kê trước khi sửa.
2. **Không có Category**. Chỉ có Week; giữ nguyên 100 ID JAVA001–JAVA100 và 12 Week; liên kết đúng. Nếu Week đã tồn tại thì tái sử dụng, không tạo trùng.
3. Method/Class/Program là cấu trúc bài nộp/chấm, không phải Category. Ứng dụng thay đổi template và judge theo trường `java_structure`.
4. Giữ giao diện CodeBank hiện tại và tất cả dữ liệu người dùng. Không xoá database, không reset migration, không force overwrite bài đã sử dụng trong đề thi. Nếu ID trùng, báo cáo và áp dụng upsert an toàn theo phiên bản hoặc skip có log.
5. Bảo mật: **KHÔNG** trả `solution/` hoặc `tests/hidden/` từ API sinh viên, nguồn web tĩnh, log phản hồi, hoặc download package. Chỉ admin/giảng viên đủ quyền được xem solution; judge truy cập nội bộ. Không chạy code sinh viên ở host/backend process. Dùng sandbox container/worker, tắt network, giới hạn CPU/RAM/process/filesystem/output/time, bảo vệ Docker socket và credentials.
6. Gói bài gồm 314 test khởi đầu. Không được mặc định báo mọi bài đạt chất lượng giáo dục; cần chạy thêm kiểm thử phản ví dụ, đầu vào biên và kiểm tra tính nhất quán đề–code–test trước khi publish.

## PHASE 0 – Audit

- Xác định schema và endpoint hiện có cho `problems`, `problem_versions`, `weeks`, `week_problems`, `test_cases`, `template`, `judge_config`, `submissions`, `judge_results`.
- Xác định hệ thống chấm Java có Program/Method/Class không. Kiểm tra Java/JDK và cơ chế sandbox, queue.
- Đọc `README.md`, `manifest.json`, `weeks.json`, chọn ba mẫu JAVA001 (Program), JAVA028 (Method), JAVA064 (Class) để kiểm chứng hợp đồng import trước.
- Trả về bảng hiện trạng và kế hoạch thay đổi. Sau đó thực hiện tiếp các phase, không viết lại kiến trúc nếu có thể tái sử dụng.

## PHASE 1 – Parser + Import Preview

- Tạo luồng Admin Import OJ ZIP và CLI idempotent/seed command cho package trên.
- Giải nén ở vùng tạm an toàn, giới hạn file count, tổng dung lượng, chống zip-slip, symlink traversal, zip bomb.
- Đọc `manifest.json`, xác nhận 100 bài, 12 Week, ID duy nhất, tất cả đường dẫn tồn tại và trỏ trong thư mục bài.
- Với từng bài đọc `problem.json`, `statement.md`, `starter/`, `solution/`, `judge_config.json` và từng `test_cases[]`.
- Preview mapping field sang DB, kiểm tra lỗi format, mã trùng, Week trùng, thiếu file, tổng weight.
- Cho xác nhận import, hiển thị báo cáo thành công/thất bại/skip theo từng bài. Không trả thông báo thành công trước khi transaction commit.

## PHASE 2 – Backend + Database

- Mở rộng schema bằng migration an toàn nếu chưa có đủ problem_versions, files, judge config, test group, test case public/hidden, Week mapping và validation state.
- `problem_id` duy nhất; đề gốc giữ status Draft. Snapshot/version không thay đổi khi đề đã dùng trong Assignment/Exam.
- Lưu test/solution ở private object storage hoặc vùng private file system; không mount public static.
- API giáo viên cho import/preview/validation và API sinh viên chỉ trả statement, starter, sample test được phép.
- Mọi thao tác import thực hiện theo transaction hoặc atomic per-problem unit, có rollback/retry và log.

## PHASE 3 – Judge Adapter

**Program:** Biên dịch `Main.java`; chạy với stdin/stdout, so sánh expected theo exact normalized line endings. Với JAVA091/092/094, mỗi fixture là nội dung file sandbox, đường dẫn được truyền vào `args[0]`. Phân biệt CE, RE, TLE, MLE, WA và AC.

**Method:** Biên dịch `Solution.java` cùng trusted harness, gọi đúng static method và test cả mảng bị thay đổi với các method void. Java snippet của gói ở `tests/{public|hidden}/TC*.java.snippet`; có expected text. Chuyển sang JUnit nếu nền tảng hiện có JUnit, nhưng PHẢI bảo toàn tiêu chí đầu ra. `JAVA077` có Shape helper; `JAVA086` có Product helper. Đảm bảo không để code sinh viên định nghĩa class/harness có thể override cơ chế chấm.

**Class:** Biên dịch class và interface; dùng trusted harness để test constructors/getters/setters, API, Reflection checks và behavioral assertions. Một số bài có nhiều class trong cùng source, ví dụ inheritance/interface. Không áp dụng đơn thuần stdin/stdout.

**Scoring:** Chấm từng test theo trọng số, tổng tối đa 100 điểm. Bài chỉ AC khi vượt tất cả test. Một test WA không đồng nghĩa toàn bộ bài được 0 nếu bật partial scoring. Snapshot test suite theo phiên bản.

**Security:** Trusted harness vẫn phải chạy trong sandbox vì có thể gọi code sinh viên. Nghiêm cấm thực thi code sinh viên bằng `javac/java` trực tiếp trên web server. Chỉ truyền kết quả tổng hợp ra ngoài và không lộ hidden fixtures.

## PHASE 4 – Giao diện người dùng

- Trang Theo Week phải hiển thị đúng 12 Week và 100 bài; không có tab Category.
- Trang bài tập sinh viên hiện đề bài, starter, editor Java, Run sample và Submit.
- `Run sample` chỉ dùng public test; `Submit` chạy cả public+hidden.
- Hiển thị AC, WA, CE, RE, TLE, MLE, điểm và trạng thái queue. Cấp quyền rõ cho giảng viên xem test/solution.
- Trang giảng viên xem test case và sửa theo Problem Builder, yêu cầu revalidate trước Publish.

## PHASE 5 – Kiểm thử bắt buộc

- Với JAVA001, JAVA028, JAVA064: import → mở UI → Run sample → Submit lời giải chuẩn → AC → submit lời giải sai → WA/CE → xác nhận hidden test không rò rỉ.
- Mở rộng kiểm thử cho toàn bộ 100 bài. Dùng `verify_reference.py --all` CHỈ với lời giải tin cậy để kiểm tra nội dung package offline; không dùng script đó làm production judge.
- Chạy reference solution trong production sandbox cho tất cả test; kiểm tra pass 100%. Thiết kế ít nhất một lời giải sai cho từng bài (hoặc ghi rõ bài nào chưa có) để xác nhận test có khả năng phát hiện lỗi.
- Thực hiện kiểm tra seed lại lần hai: không tăng tổng số bài hoặc tạo Week trùng.
- Kiểm tra reload, quyền truy cập, pagination, performance, hết thời gian, crash worker, rejudge và resume.
- Không tự động chuyển trạng thái Published khi chưa có đủ bằng chứng kiểm định và giảng viên duyệt.

## Kết quả bàn giao

1. Source thay đổi + migration và lệnh chạy.
2. Preview kết quả import: 100 bài, 12 Week, số test/bài, file thiếu/trùng.
3. API thật và screenshot UI.
4. Báo cáo kiểm thử toàn bộ bài gồm số pass, lỗi compile/runtime, kết quả mẫu AC và WA.
5. Log xác minh hidden tests/solution không bị lộ.
6. Các tồn tại và những bài cần giảng viên duyệt.

**Không dùng mock. Không ghi 'đã AC' nếu chưa chạy thật qua judge. Giữ nguyên giao diện và các module khác.**
