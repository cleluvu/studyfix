# Tổng từng hàng

**Mã bài:** JAVA038  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc r,c và ma trận nguyên; in r tổng theo từng hàng, mỗi hàng một kết quả.

## Ràng buộc và trường hợp biên

Hỗ trợ giá trị âm.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
