# Interface Payable

**Mã bài:** JAVA076  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo interface Payable với double payment(); class Invoice(quantity,unitPrice) và SalaryEmployee(base,bonus) implements Payable.

## Ràng buộc và trường hợp biên

Giá trị tiền không âm.

## Quy ước kiểm thử bổ sung

Invoice(int quantity,double unitPrice), SalaryEmployee(double salary), payment() trả giá trị double.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
