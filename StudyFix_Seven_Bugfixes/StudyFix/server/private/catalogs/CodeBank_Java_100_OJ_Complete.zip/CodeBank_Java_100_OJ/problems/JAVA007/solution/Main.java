import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);double k=sc.nextDouble(),p=sc.nextDouble();System.out.printf(java.util.Locale.ROOT,"%.2f%n",k*p);}
}
