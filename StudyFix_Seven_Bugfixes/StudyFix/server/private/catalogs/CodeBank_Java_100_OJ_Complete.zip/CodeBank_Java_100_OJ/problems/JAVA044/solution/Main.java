import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);int r=sc.nextInt(),c=sc.nextInt();for(int i=0;i<r*c;i++)sc.nextInt();System.out.println(r==1||c==1?r*c:2*r+2*c-4);}
}
