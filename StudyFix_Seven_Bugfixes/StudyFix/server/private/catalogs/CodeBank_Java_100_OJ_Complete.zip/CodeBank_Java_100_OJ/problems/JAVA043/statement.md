# Nhân hai ma trận

**Mã bài:** JAVA043  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc r1,c1 rồi ma trận A; đọc r2,c2 rồi ma trận B; nếu c1 khác r2 in INVALID, ngược lại in A×B.

## Ràng buộc và trường hợp biên

Sử dụng long cho tích và tổng tích.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
