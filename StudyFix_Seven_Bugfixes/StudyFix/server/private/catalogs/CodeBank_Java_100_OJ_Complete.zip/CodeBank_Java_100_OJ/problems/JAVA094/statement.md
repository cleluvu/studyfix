# Xử lý CSV sinh viên

**Mã bài:** JAVA094  
**Week:** 11 – Ngoại lệ và tệp tin  
**Mức độ:** Khó  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Nhận đường dẫn CSV UTF-8 qua args[0], mỗi dòng có id,name,score; bỏ dòng header và in điểm trung bình với 2 chữ số.

## Ràng buộc và trường hợp biên

Trường không chứa dấu phẩy/ngoặc kép; dữ liệu hợp lệ; không có dữ liệu in 0.00.

## Quy ước kiểm thử bổ sung

File CSV đơn giản: không chứa dấu phẩy trong tên hoặc quoted fields; header id,name,score; nếu không có bản ghi in 0.00.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
