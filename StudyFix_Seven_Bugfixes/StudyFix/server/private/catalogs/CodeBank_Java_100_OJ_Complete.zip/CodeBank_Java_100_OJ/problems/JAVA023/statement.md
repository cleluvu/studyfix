# Liệt kê ước số

**Mã bài:** JAVA023  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n nguyên dương; in tất cả ước số dương của n theo thứ tự tăng dần, cách nhau một dấu cách.

## Ràng buộc và trường hợp biên

n có thể lên tới 10^9.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
