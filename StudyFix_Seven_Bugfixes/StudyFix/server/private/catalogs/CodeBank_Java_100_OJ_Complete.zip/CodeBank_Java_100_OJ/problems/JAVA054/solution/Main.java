import java.util.*;import java.io.*;import java.nio.file.*;
public class Main {
static void hanoi(int n,String a,String b,String c){if(n==0)return;hanoi(n-1,a,c,b);System.out.println(a+" "+c);hanoi(n-1,b,a,c);}
public static void main(String[] args) throws Exception { Scanner sc=new Scanner(System.in);String line=sc.hasNextLine()?sc.nextLine().trim():"";if(line.isEmpty()){System.out.println("NONE");}else{java.util.TreeMap<String,Integer> m=new java.util.TreeMap<>();for(String w:line.split("\s+"))m.merge(w.toLowerCase(java.util.Locale.ROOT),1,Integer::sum);String best="";int mx=-1;for(var e:m.entrySet())if(e.getValue()>mx){mx=e.getValue();best=e.getKey();}System.out.println(best);}}
}
