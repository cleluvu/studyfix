# Kế thừa Person và Student

**Mã bài:** JAVA073  
**Week:** 9 – Kế thừa và đa hình  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo Person(name,age) và Student extends Person thêm studentId; override toString() trả studentId:name:age.

## Ràng buộc và trường hợp biên

Tuổi không âm.

## Quy ước kiểm thử bổ sung

Person(String name,int age), Student(String name,int age,String studentId), toString() chính xác dạng "studentId name age".

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
