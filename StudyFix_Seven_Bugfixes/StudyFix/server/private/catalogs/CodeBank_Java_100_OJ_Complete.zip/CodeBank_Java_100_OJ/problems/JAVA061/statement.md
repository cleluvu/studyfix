# Đệ quy kiểm tra palindrome

**Mã bài:** JAVA061  
**Week:** 7 – Phương thức và đệ quy  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static boolean isPalindrome(String s,int left,int right) kiểm tra đoạn s[left..right] bằng đệ quy.

## Ràng buộc và trường hợp biên

Chỉ số hợp lệ, left>right cho true.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static boolean isPalindrome(String s,int left,int right)
```
