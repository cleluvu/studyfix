public class Solution {
    public static int[][] rotateClockwise(int[][] a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
