public class Solution {
    public static long mainDiagonalSum(int[][] a) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
