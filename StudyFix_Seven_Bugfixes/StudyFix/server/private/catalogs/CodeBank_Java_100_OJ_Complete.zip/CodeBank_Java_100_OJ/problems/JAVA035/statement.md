# Trộn hai mảng đã sắp xếp

**Mã bài:** JAVA035  
**Week:** 4 – Mảng một chiều  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static int[] mergeSorted(int[] a,int[] b) trả mảng tăng dần gồm toàn bộ phần tử hai mảng đầu vào.

## Ràng buộc và trường hợp biên

Hai mảng đầu vào đã tăng dần; có thể rỗng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static int[] mergeSorted(int[] a,int[] b)
```
