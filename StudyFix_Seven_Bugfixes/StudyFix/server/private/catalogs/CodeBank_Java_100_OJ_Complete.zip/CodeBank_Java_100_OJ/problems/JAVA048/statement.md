# Kiểm tra chuỗi palindrome

**Mã bài:** JAVA048  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static boolean isPalindrome(String s), bỏ qua khoảng trắng và phân biệt chữ hoa/chữ thường theo quy định không phân biệt hoa thường.

## Ràng buộc và trường hợp biên

Chỉ cần xét ký tự ASCII và chữ số.

## Quy ước kiểm thử bổ sung

Chỉ bỏ các ký tự whitespace; so sánh không phân biệt hoa/thường.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static boolean isPalindrome(String s)
```
