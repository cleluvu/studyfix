# Giao của hai tập hợp

**Mã bài:** JAVA083  
**Week:** 10 – Collections và Generics  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static Set<Integer> intersection(Set<Integer> a,Set<Integer> b) trả các phần tử thuộc cả hai tập.

## Ràng buộc và trường hợp biên

Không sửa đầu vào.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static java.util.Set<Integer> intersection(java.util.Set<Integer> a,java.util.Set<Integer> b)
```
