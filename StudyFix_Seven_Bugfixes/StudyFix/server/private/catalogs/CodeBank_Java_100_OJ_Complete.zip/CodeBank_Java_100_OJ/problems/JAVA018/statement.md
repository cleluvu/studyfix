# Tính giai thừa

**Mã bài:** JAVA018  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n nguyên trong [0,20]; in n! bằng kiểu long.

## Ràng buộc và trường hợp biên

0! = 1.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
