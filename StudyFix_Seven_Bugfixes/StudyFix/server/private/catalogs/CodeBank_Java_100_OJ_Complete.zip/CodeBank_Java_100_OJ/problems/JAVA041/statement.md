# Tổng đường chéo chính

**Mã bài:** JAVA041  
**Week:** 5 – Mảng hai chiều  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static long mainDiagonalSum(int[][] a) trả tổng đường chéo chính của ma trận vuông.

## Ràng buộc và trường hợp biên

a có thể là ma trận 0×0, trả 0.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static long mainDiagonalSum(int[][] a)
```
