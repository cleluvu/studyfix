# Sắp xếp nổi bọt có đếm hoán đổi

**Mã bài:** JAVA095  
**Week:** 12 – Thuật toán và bài tổng hợp  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc n và n số nguyên; sắp bằng bubble sort và in số lần đổi chỗ, sau đó in mảng tăng dần.

## Ràng buộc và trường hợp biên

n<=2000; dùng đổi chỗ chỉ khi a[j]>a[j+1].

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
