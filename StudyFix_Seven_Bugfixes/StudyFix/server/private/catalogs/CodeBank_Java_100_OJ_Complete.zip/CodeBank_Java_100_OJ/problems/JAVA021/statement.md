# Tổng chữ số

**Mã bài:** JAVA021  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc số nguyên 64-bit n; in tổng các chữ số của trị tuyệt đối.

## Ràng buộc và trường hợp biên

Hỗ trợ số âm, n=0 và Long.MIN_VALUE.

## Quy ước kiểm thử bổ sung

Dấu âm không tính vào tổng các chữ số.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
