# Lớp Employee tính lương

**Mã bài:** JAVA071  
**Week:** 8 – Lớp và đối tượng  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Class

## Yêu cầu

Tạo class Employee với name, baseSalary, bonus; constructor, setters hợp lệ và monthlySalary() trả tổng baseSalary+bonus.

## Ràng buộc và trường hợp biên

Không cho giá trị lương hoặc thưởng âm.

## Quy ước kiểm thử bổ sung

Constructor Employee(String name,double baseSalary,double bonus); setters setBaseSalary(double),setBonus(double); monthlySalary trả tổng; lương/bonus âm ném IllegalArgumentException.

## Cấu trúc code bắt buộc

Tạo các class/interface, constructor và API đúng mô tả. Không yêu cầu viết `main`. Java Judge thực hiện các lời gọi, phép kiểm tra hành vi và cấu trúc.
