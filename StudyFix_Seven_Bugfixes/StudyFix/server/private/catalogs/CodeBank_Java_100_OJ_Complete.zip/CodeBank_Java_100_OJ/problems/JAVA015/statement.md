# Tính giá vé theo độ tuổi

**Mã bài:** JAVA015  
**Week:** 2 – Rẽ nhánh và điều kiện  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc tuổi nguyên không âm và giá vé chuẩn nguyên; trẻ dưới 6 miễn phí, 6–17 trả 50%, từ 60 trở lên trả 70%, còn lại trả 100%; in số tiền với 2 chữ số.

## Ràng buộc và trường hợp biên

Áp dụng đúng ưu tiên các mức tuổi.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
