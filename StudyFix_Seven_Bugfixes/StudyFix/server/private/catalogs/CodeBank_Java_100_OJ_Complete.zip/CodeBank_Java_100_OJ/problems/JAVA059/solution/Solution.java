import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static long power(long a,int n) {if(n==0)return 1;long t=power(a,n/2);return n%2==0?t*t:t*t*a;}}
