# Đếm tần suất bằng HashMap

**Mã bài:** JAVA082  
**Week:** 10 – Collections và Generics  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static Map<String,Integer> frequency(List<String> words) trả map đếm tần suất từ, phân biệt hoa thường.

## Ràng buộc và trường hợp biên

Danh sách có thể rỗng.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static java.util.Map<String,Integer> frequency(java.util.List<String> words)
```
