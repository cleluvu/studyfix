import java.util.*;import java.nio.file.*;import java.io.*;
public class AreaCalculator {public static double area(double radius){return Math.PI*radius*radius;}public static double area(double width,double height){return width*height;}}
