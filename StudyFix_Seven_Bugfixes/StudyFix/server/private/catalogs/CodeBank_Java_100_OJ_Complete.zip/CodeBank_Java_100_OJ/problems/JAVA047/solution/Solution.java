import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static String reverseText(String s) {int[]a=s.codePoints().toArray();StringBuilder b=new StringBuilder();for(int i=a.length-1;i>=0;i--)b.appendCodePoint(a[i]);return b.toString();}}
