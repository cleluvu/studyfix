# Chuẩn hóa khoảng trắng

**Mã bài:** JAVA049  
**Week:** 6 – Chuỗi ký tự  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static String normalizeSpaces(String s) xóa khoảng trắng đầu/cuối và thay chuỗi whitespace liên tiếp bằng một dấu cách.

## Ràng buộc và trường hợp biên

Xử lý tab và newline.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static String normalizeSpaces(String s)
```
