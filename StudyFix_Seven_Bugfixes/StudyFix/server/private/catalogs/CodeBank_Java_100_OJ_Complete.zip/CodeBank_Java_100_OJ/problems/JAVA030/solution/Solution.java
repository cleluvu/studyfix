import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static int firstIndex(int[] a,int x) {for(int i=0;i<a.length;i++)if(a[i]==x)return i;return -1;}}
