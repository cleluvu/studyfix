public class Solution {
    public static String normalizeSpaces(String s) {
        // TODO: Cai dat phuong thuc.
        throw new UnsupportedOperationException("TODO");
    }
}
