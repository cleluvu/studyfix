# Ước chung lớn nhất

**Mã bài:** JAVA024  
**Week:** 3 – Vòng lặp và bài toán số  
**Mức độ:** Dễ  
**Cấu trúc nộp bài:** Program

## Yêu cầu

Đọc hai số nguyên không âm a,b, không đồng thời bằng 0; in UCLN theo thuật toán Euclid.

## Ràng buộc và trường hợp biên

UCLN(a,0)=a.

## Đầu vào và đầu ra

Đọc dữ liệu theo đúng thứ tự mô tả trong yêu cầu. Xuất kết quả chính xác theo format đã quy định. Dùng `Main.java`, class `Main` và `public static void main(String[] args)`.
