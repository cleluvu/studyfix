# Ghi danh sách tên ra tệp

**Mã bài:** JAVA093  
**Week:** 11 – Ngoại lệ và tệp tin  
**Mức độ:** Trung bình  
**Cấu trúc nộp bài:** Method

## Yêu cầu

Hoàn thiện public static void saveNames(Path path,List<String> names) ghi mỗi tên thành một dòng UTF-8.

## Ràng buộc và trường hợp biên

Cho phép danh sách rỗng, ném IOException theo API.

## Quy ước kiểm thử bổ sung

File UTF-8, mỗi tên một dòng, newline theo mặc định máy chấm; sử dụng Files.readAllLines để kiểm tra.

## Cấu trúc code bắt buộc

Hoàn thiện phương thức trong class `Solution`, không cần viết `main`. Java Judge gọi phương thức và đối chiếu kết quả/trạng thái dữ liệu.

```java
public static void saveNames(java.nio.file.Path path,java.util.List<String> names)
```
