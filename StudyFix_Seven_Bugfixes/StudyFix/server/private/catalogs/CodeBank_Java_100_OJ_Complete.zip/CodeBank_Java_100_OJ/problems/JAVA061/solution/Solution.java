import java.util.*;import java.nio.file.*;import java.io.*;
public class Solution {public static boolean isPalindrome(String s,int left,int right) {if(left>=right)return true;return s.charAt(left)==s.charAt(right)&&isPalindrome(s,left+1,right-1);}}
